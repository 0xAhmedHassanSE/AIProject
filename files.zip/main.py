"""
================================================================================
  main.py — Entry Point for the Maze RL Solver
================================================================================
  Author  : Expert AI Researcher / Senior Python Developer
  Project : Maze Solver using Reinforcement Learning

  Description:
    Orchestrates the full pipeline:
      1. Create the Custom Maze Environment
      2. Instantiate the Q-Learning Agent
      3. Run the Training Loop
      4. Evaluate the learned policy
      5. Generate and save all visualisations

  Usage:
      python main.py

  Optional CLI flags (edit CONFIG below to adjust):
      - N_EPISODES   : Number of training episodes
      - ALPHA        : Learning rate
      - GAMMA        : Discount factor
      - EPSILON_DECAY: Exploration decay rate
      - SAVE_PLOTS   : Whether to save figures to disk
      - OUTPUT_DIR   : Directory for saved figures
================================================================================
"""

import os
import sys

# Install gymnasium shim BEFORE any other local imports so that maze_env.py
# can always `import gymnasium` regardless of the execution environment.
import gym_compat  # noqa: F401  (side-effect import — installs shim if needed)

# ---------------------------------------------------------------------------
# ── Configuration (edit these to experiment) ───────────────────────────────
# ---------------------------------------------------------------------------
CONFIG = {
    # Environment
    "MAX_STEPS_PER_EPISODE": 500,

    # Training
    "N_EPISODES"            : 3000,
    "LOG_INTERVAL"          : 300,

    # Q-Learning Hyperparameters
    "ALPHA"                 : 0.1,     # learning rate α
    "GAMMA"                 : 0.99,    # discount factor γ
    "EPSILON_START"         : 1.0,     # initial ε
    "EPSILON_MIN"           : 0.01,    # minimum ε after decay
    "EPSILON_DECAY"         : 0.995,   # multiplicative decay per episode

    # Reproducibility
    "SEED"                  : 42,

    # Output
    "SAVE_PLOTS"            : True,
    "OUTPUT_DIR"            : "outputs",
    "SMOOTH_WINDOW"         : 50,
}

# ---------------------------------------------------------------------------
# ── Imports ────────────────────────────────────────────────────────────────
# ---------------------------------------------------------------------------
from maze_env       import CustomMazeEnv
from q_learning_agent import QLearningAgent
from train          import TrainingLoop
from visualization  import (
    plot_training_dashboard,
    plot_learning_curve,
    plot_steps_reduction,
    plot_epsilon_decay,
    render_maze_path,
    render_q_value_heatmap,
    render_policy_map,
)


# ---------------------------------------------------------------------------
# ── Helpers ────────────────────────────────────────────────────────────────
# ---------------------------------------------------------------------------

def _out(filename: str) -> str | None:
    """Return full output path or None (if saving is disabled)."""
    if not CONFIG["SAVE_PLOTS"]:
        return None
    os.makedirs(CONFIG["OUTPUT_DIR"], exist_ok=True)
    return os.path.join(CONFIG["OUTPUT_DIR"], filename)


def banner(text: str) -> None:
    """Print a section banner."""
    print(f"\n{'─'*60}")
    print(f"  {text}")
    print(f"{'─'*60}")


# ---------------------------------------------------------------------------
# ── Main Pipeline ──────────────────────────────────────────────────────────
# ---------------------------------------------------------------------------

def main() -> None:

    # ── 1. Create Environment ───────────────────────────────────────────────
    banner("Step 1 / 5 — Creating Custom Maze Environment")

    env = CustomMazeEnv(
        max_steps=CONFIG["MAX_STEPS_PER_EPISODE"],
    )
    print(f"  Maze size    : {env.n_rows} × {env.n_cols}")
    print(f"  Total states : {env.n_states}")
    print(f"  Action space : {env.n_actions}  (Up/Down/Left/Right)")
    print(f"  Start        : {env.start_pos}")
    print(f"  Exit         : {env.exit_pos}")

    # Print initial maze layout
    print("\n  Maze layout (# = wall, . = free, S = start, E = exit):\n")
    print(env.render())

    # ── 2. Instantiate Agent ────────────────────────────────────────────────
    banner("Step 2 / 5 — Instantiating Q-Learning Agent")

    agent = QLearningAgent(
        n_states      = env.n_states,
        n_actions     = env.n_actions,
        alpha         = CONFIG["ALPHA"],
        gamma         = CONFIG["GAMMA"],
        epsilon       = CONFIG["EPSILON_START"],
        epsilon_min   = CONFIG["EPSILON_MIN"],
        epsilon_decay = CONFIG["EPSILON_DECAY"],
        seed          = CONFIG["SEED"],
    )
    print(f"  Q-table shape  : {agent.q_table.shape}")
    print(f"  α (learn rate) : {agent.alpha}")
    print(f"  γ (discount)   : {agent.gamma}")
    print(f"  ε initial      : {agent.epsilon}")
    print(f"  ε decay        : {agent.epsilon_decay}")
    print(f"  ε minimum      : {agent.epsilon_min}")

    # ── 3. Train ────────────────────────────────────────────────────────────
    banner("Step 3 / 5 — Running Training Loop")

    loop = TrainingLoop(
        env          = env,
        agent        = agent,
        n_episodes   = CONFIG["N_EPISODES"],
        log_interval = CONFIG["LOG_INTERVAL"],
        verbose      = True,
    )
    metrics = loop.run()

    # ── 4. Evaluate Learned Policy ──────────────────────────────────────────
    banner("Step 4 / 5 — Evaluating Greedy Policy")

    optimal_path = agent.get_best_path(env)
    success      = optimal_path[-1] == env.exit_pos
    path_len     = len(optimal_path) - 1

    print(f"\n  Policy evaluation (ε = 0 / pure exploitation):")
    print(f"    Reached exit  : {success}")
    print(f"    Path length   : {path_len} steps")
    print(f"    Path          : {optimal_path}\n")

    if success:
        print("  ✅  Agent successfully learned the optimal maze path!")
    else:
        print("  ⚠️  Agent did NOT reach the exit — try more episodes or tune hyperparams.")

    # ── 5. Visualisations ───────────────────────────────────────────────────
    banner("Step 5 / 5 — Generating Visualisations")

    W = CONFIG["SMOOTH_WINDOW"]

    # 5a. Training Dashboard (all 4 metrics)
    print("  Plotting: Training Dashboard …")
    plot_training_dashboard(
        episode_rewards = metrics.episode_rewards,
        episode_steps   = metrics.episode_steps,
        epsilon_history = metrics.epsilon_per_episode,
        td_errors       = metrics.td_errors_mean,
        window          = W,
        save_path       = _out("01_training_dashboard.png"),
    )

    # 5b. Individual learning curve
    print("  Plotting: Learning Curve …")
    plot_learning_curve(
        episode_rewards = metrics.episode_rewards,
        window          = W,
        save_path       = _out("02_learning_curve.png"),
    )

    # 5c. Steps reduction
    print("  Plotting: Steps Reduction …")
    plot_steps_reduction(
        episode_steps = metrics.episode_steps,
        window        = W,
        save_path     = _out("03_steps_reduction.png"),
    )

    # 5d. Epsilon decay
    print("  Plotting: Epsilon Decay …")
    plot_epsilon_decay(
        epsilon_history = metrics.epsilon_per_episode,
        save_path       = _out("04_epsilon_decay.png"),
    )

    # 5e. Maze with optimal path
    if success:
        print("  Plotting: Maze Path …")
        render_maze_path(
            maze      = env.get_maze_copy(),
            path      = optimal_path,
            start_pos = env.start_pos,
            exit_pos  = env.exit_pos,
            save_path = _out("05_maze_optimal_path.png"),
        )

    # 5f. Q-Value heatmap
    print("  Plotting: Q-Value Heatmap …")
    render_q_value_heatmap(
        q_table   = agent.q_table,
        maze      = env.get_maze_copy(),
        n_cols    = env.n_cols,
        start_pos = env.start_pos,
        exit_pos  = env.exit_pos,
        save_path = _out("06_q_value_heatmap.png"),
    )

    # 5g. Policy arrow map
    print("  Plotting: Policy Arrow Map …")
    render_policy_map(
        q_table   = agent.q_table,
        maze      = env.get_maze_copy(),
        n_cols    = env.n_cols,
        start_pos = env.start_pos,
        exit_pos  = env.exit_pos,
        save_path = _out("07_policy_map.png"),
    )

    # ── Final Summary ───────────────────────────────────────────────────────
    banner("Run Complete")
    if CONFIG["SAVE_PLOTS"]:
        output_dir = os.path.abspath(CONFIG["OUTPUT_DIR"])
        print(f"  All figures saved to: {output_dir}/")
        for f in sorted(os.listdir(output_dir)):
            print(f"    • {f}")

    print(f"\n  Training stats:")
    print(f"    Total episodes  : {metrics.n_episodes:,}")
    print(f"    Success rate    : {100 * metrics.success_rate:.1f}%")
    print(f"    Best path found : {metrics.best_episode_steps} steps")
    print(f"    Training time   : {metrics.training_time_sec:.2f}s")
    print()


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    main()
